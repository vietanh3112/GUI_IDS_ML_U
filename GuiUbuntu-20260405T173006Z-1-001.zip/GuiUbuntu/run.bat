@echo off
title ANM ML Monitor
cd /d "%~dp0"
python --version >nul 2>&1 || (echo Python not found & pause & exit /b 1)
if not exist ".venv" (
    python -m venv .venv
    call .venv\Scripts\activate.bat
    pip install -r requirements.txt
) else (
    call .venv\Scripts\activate.bat
)
python anm_monitor.py
pause
