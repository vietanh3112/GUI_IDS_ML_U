"""
ANM Monitor — SSH + Suricata EVE + pfSense + XGBoost ML Real-time
1 file: SSH vao server, tail eve.json (Suricata) + filter.log (pfSense), ML phan loai, alert live.

  pip install customtkinter paramiko xgboost numpy
  python anm_monitor.py
"""
from __future__ import annotations

import json
import math
import pickle
import re
import threading
import time
import tkinter as tk
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

import customtkinter as ctk
import numpy as np

try:
    import paramiko
except ImportError:
    paramiko = None

# ── Paths ──
_SCRIPT_DIR = Path(__file__).resolve().parent
_MODEL_DIR = _SCRIPT_DIR

# ── Theme ──
_BG = "#0d1117"
_CARD = "#161b22"
_BORDER = "#30363d"
_ACCENT = "#58a6ff"
_GREEN = "#3fb950"
_RED = "#f85149"
_ORANGE = "#d29922"
_CYAN = "#39d2c0"
_PURPLE = "#bc8cff"
_TEXT = "#e6edf3"
_MUTED = "#8b949e"

# ── Constants ──
_PROTO_MAP = {"tcp": 6, "udp": 17, "icmp": 1, "igmp": 2, "gre": 47}
_SERVICE_PORTS = {21, 22, 25, 53, 80, 110, 143, 443, 445, 993, 995, 3306, 3389, 5432, 8080, 8443}
_HTTP_METHOD_MAP = {"GET": 1, "POST": 2, "PUT": 3, "DELETE": 4, "HEAD": 5, "OPTIONS": 6, "PATCH": 7}
_EVENT_TYPE_MAP = {"flow": 1, "alert": 2, "http": 3, "dns": 4, "tls": 5, "ssh": 6,
                   "fileinfo": 7, "stats": 8, "anomaly": 9, "drop": 10}
_SQLI_PAT = re.compile(r"(union\s+select|or\s+1\s*=\s*1|'\s*or\s*'|drop\s+table|;\s*delete|;\s*insert|--\s*$|/\*.*\*/)", re.I)
_XSS_PAT = re.compile(r"(<script|javascript:|onerror\s*=|onload\s*=|<img\s+[^>]*on)", re.I)
_LOGIN_PAT = re.compile(r"(login|passwd|password|user|admin|auth|session)", re.I)
_ADMIN_PAT = re.compile(r"/(admin|wp-admin|phpmyadmin|cpanel|manager|console|dashboard)", re.I)
_SUSP_UA = {"sqlmap", "nikto", "nmap", "masscan", "curl", "wget", "python-requests", "gobuster", "dirbuster"}

# pfSense filter.log regex
_FILTER_RE = re.compile(r"^(?P<ts>[A-Za-z]+ +\d+ [\d:]+)\s+\S+\s+filterlog\[\d+\]:\s*(?P<csv>.+)$")
_IP_RE = re.compile(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b")


def _parse_pf_line(raw: str) -> dict[str, Any] | None:
    m = _FILTER_RE.match(raw.strip())
    if not m:
        return None
    parts = m.group("csv").split(",")
    if len(parts) < 10:
        return None
    action = parts[6].strip().lower() if len(parts) > 6 else ""
    iface = parts[4].strip() if len(parts) > 4 else ""
    ips = _IP_RE.findall(m.group("csv"))
    src = ips[0] if len(ips) >= 1 else ""
    dst = ips[1] if len(ips) >= 2 else ""
    proto = ""
    src_port = dst_port = ""
    if len(parts) > 8 and parts[8].strip() in ("4", "6"):
        proto = parts[16].strip().lower() if len(parts) > 16 else ""
        if proto in ("tcp", "udp") and len(parts) > 21:
            src_port = parts[20].strip()
            dst_port = parts[21].strip()
    else:
        proto = parts[8].strip().lower() if len(parts) > 8 else ""
    return {"_src": "pf", "ts": m.group("ts"), "action": action, "iface": iface,
            "proto": proto, "src": src, "dst": dst, "src_port": src_port, "dst_port": dst_port}


def _parse_eve_line(raw: str) -> dict[str, Any] | None:
    """Parse 1 dong NDJSON tu Suricata eve.json."""
    try:
        ev = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return None
    if not isinstance(ev, dict):
        return None
    return {
        "_src": "eve", "_raw": ev,
        "ts": ev.get("timestamp", ""),
        "event_type": ev.get("event_type", ""),
        "src": ev.get("src_ip", ""),
        "dst": ev.get("dest_ip", ""),
        "src_port": str(ev.get("src_port", "")),
        "dst_port": str(ev.get("dest_port", "")),
        "proto": (ev.get("proto") or "").lower(),
        "app_proto": (ev.get("app_proto") or "").lower(),
        "action": "alert" if ev.get("event_type") == "alert" else "",
        # Suricata alert
        "alert_sig": (ev.get("alert") or {}).get("signature", ""),
        "alert_sev": (ev.get("alert") or {}).get("severity", 0),
        "alert_cat": (ev.get("alert") or {}).get("category", ""),
        # Flow stats
        "flow": ev.get("flow") or {},
        # HTTP
        "http": ev.get("http") or {},
        # DNS
        "dns": ev.get("dns") or {},
        # TLS
        "tls": ev.get("tls") or {},
    }


# ══════════════════════════════════════════════════════════════════
#  ML ENGINE
# ══════════════════════════════════════════════════════════════════
class MLEngine:
    def __init__(self, model_dir: Path | str) -> None:
        model_dir = Path(model_dir)
        self.model = None
        self.feature_order: list[str] = []
        self.id_to_label: dict[str, str] = {}
        self.ready = False
        self._flow_table: dict[str, dict[str, Any]] = {}

        try:
            schema = json.loads((model_dir / "feature_schema.json").read_text("utf-8"))
            self.feature_order = schema["feature_order"]
            lm = json.loads((model_dir / "label_mapping.json").read_text("utf-8"))
            self.id_to_label = lm.get("id_to_label", {})
            self.model = pickle.loads((model_dir / "model.pkl").read_bytes())
            self.ready = True
        except Exception as e:
            print(f"[ML] Load failed: {e}")

    def predict(self, entry: dict[str, Any]) -> tuple[str, float, dict[str, float]]:
        if not self.ready or not self.model:
            return "", 0.0, {}
        src = entry.get("_src", "pf")
        feat = self._build_eve_features(entry) if src == "eve" else self._build_pf_features(entry)
        arr = np.array([[feat.get(f, 0.0) for f in self.feature_order]], dtype=np.float32)
        try:
            proba = self.model.predict_proba(arr)[0]
            idx = int(np.argmax(proba))
            conf = float(proba[idx])
            label = self.id_to_label.get(str(idx), f"class_{idx}")
            proba_dict = {self.id_to_label.get(str(i), f"c{i}"): round(float(p), 4)
                          for i, p in enumerate(proba) if p > 0.01}
            return label, conf, proba_dict
        except Exception as e:
            return f"ERR:{e}", 0.0, {}

    # ── Eve features (rich — Suricata has flow/HTTP/DNS/TLS) ──
    def _build_eve_features(self, entry: dict[str, Any]) -> dict[str, float]:
        feat: dict[str, float] = {f: 0.0 for f in self.feature_order}
        ev = entry.get("_raw") or {}
        proto = (entry.get("proto") or "").lower()

        # dest_port
        try:
            feat["dest_port"] = float(ev.get("dest_port") or 0)
        except (ValueError, TypeError):
            pass

        feat["proto_code"] = float(_PROTO_MAP.get(proto, 0))
        feat["event_type_code"] = float(_EVENT_TYPE_MAP.get(ev.get("event_type", ""), 0))

        # Alert
        alert = ev.get("alert") or {}
        if alert:
            feat["alert_present"] = 1.0
            feat["alert_severity"] = float(alert.get("severity") or 0)

        # App proto flags
        ap = (ev.get("app_proto") or "").lower()
        feat["app_proto_http"] = 1.0 if ap in ("http", "http/1.1", "http/2") else 0.0
        feat["app_proto_tls"] = 1.0 if ap == "tls" else 0.0
        feat["app_proto_dns"] = 1.0 if ap == "dns" else 0.0
        feat["app_proto_ssh"] = 1.0 if ap == "ssh" else 0.0

        # same_service_port
        try:
            dp = int(ev.get("dest_port") or 0)
            if dp in _SERVICE_PORTS:
                feat["same_service_port_flag"] = 1.0
        except (ValueError, TypeError):
            pass

        # ── Flow stats (if Suricata provides flow dict) ──
        flow = ev.get("flow") or {}
        if flow:
            start = flow.get("start")
            pkts_ts = flow.get("pkts_toserver", 0)
            pkts_tc = flow.get("pkts_toclient", 0)
            bytes_ts = flow.get("bytes_toserver", 0)
            bytes_tc = flow.get("bytes_toclient", 0)
            total_pkts = pkts_ts + pkts_tc
            total_bytes = bytes_ts + bytes_tc

            # duration from flow.age or start/end
            age = flow.get("age", 0)
            duration_us = float(age) * 1_000_000 if age else 1000.0
            duration_s = max(duration_us / 1_000_000, 0.001)

            feat["flow_duration"] = duration_us
            feat["total_fwd_packets"] = float(pkts_ts)
            feat["total_length_fwd_packets"] = float(bytes_ts)

            # Packet length estimates
            avg_fwd = bytes_ts / max(pkts_ts, 1)
            avg_bwd = bytes_tc / max(pkts_tc, 1)
            feat["fwd_pkt_len_mean"] = avg_fwd
            feat["fwd_pkt_len_max"] = avg_fwd * 1.5
            feat["fwd_pkt_len_min"] = avg_fwd * 0.3
            feat["fwd_pkt_len_std"] = avg_fwd * 0.4
            feat["bwd_pkt_len_mean"] = avg_bwd
            feat["bwd_pkt_len_max"] = avg_bwd * 1.5
            feat["bwd_pkt_len_min"] = avg_bwd * 0.3
            feat["bwd_pkt_len_std"] = avg_bwd * 0.4

            avg_all = total_bytes / max(total_pkts, 1)
            feat["min_pkt_len"] = min(avg_fwd, avg_bwd) * 0.3
            feat["max_pkt_len"] = max(avg_fwd, avg_bwd) * 1.5
            feat["pkt_len_mean"] = avg_all
            feat["pkt_len_std"] = avg_all * 0.4
            feat["pkt_len_variance"] = (avg_all * 0.4) ** 2
            feat["avg_pkt_size"] = avg_all

            feat["flow_bytes_per_s"] = float(total_bytes / duration_s)
            feat["flow_pkts_per_s"] = float(total_pkts / duration_s)
            feat["fwd_pkts_per_s"] = float(pkts_ts / duration_s)
            feat["bwd_pkts_per_s"] = float(pkts_tc / duration_s)

            feat["fwd_header_len"] = float(pkts_ts * (20 if proto == "tcp" else 8))
            feat["bwd_header_len"] = float(pkts_tc * (20 if proto == "tcp" else 8))
            feat["subflow_fwd_bytes"] = float(bytes_ts)

            # IAT estimate from duration & pkt count
            if total_pkts > 1:
                avg_iat = duration_us / (total_pkts - 1)
                feat["flow_iat_mean"] = avg_iat
                feat["flow_iat_std"] = avg_iat * 0.5
                feat["flow_iat_max"] = avg_iat * 2.0
                feat["flow_iat_min"] = avg_iat * 0.1
                feat["fwd_iat_total"] = duration_us
                feat["fwd_iat_mean"] = avg_iat
                feat["fwd_iat_std"] = avg_iat * 0.5
                feat["fwd_iat_max"] = avg_iat * 2.0
                feat["fwd_iat_min"] = avg_iat * 0.1
                feat["bwd_iat_total"] = duration_us * 0.8
                feat["bwd_iat_mean"] = avg_iat * 1.2
                feat["bwd_iat_std"] = avg_iat * 0.6
                feat["bwd_iat_max"] = avg_iat * 2.5
                feat["bwd_iat_min"] = avg_iat * 0.1

            # TCP flags heuristic
            if proto == "tcp":
                feat["ack_flag_count"] = float(max(0, total_pkts - 1))
                feat["psh_flag_count"] = float(max(0, pkts_ts - 1))
                feat["fin_flag_count"] = 1.0 if flow.get("state", "") in ("closed", "fin") else 0.0
                feat["init_win_bytes_fwd"] = 65535.0
                feat["init_win_bytes_bwd"] = 65535.0
                feat["min_seg_size_fwd"] = 20.0
                feat["act_data_pkt_fwd"] = float(max(0, pkts_ts - 1))

            # Active/Idle
            if duration_s > 0.1:
                feat["active_mean"] = duration_us * 0.6
                feat["active_max"] = duration_us * 0.8
                feat["active_min"] = duration_us * 0.2
                feat["idle_mean"] = duration_us * 0.3
                feat["idle_max"] = duration_us * 0.5

        # ── HTTP analysis ──
        http = ev.get("http") or {}
        if http:
            feat["http_present"] = 1.0
            url = http.get("url") or ""
            hostname = http.get("hostname") or ""
            ua = (http.get("http_user_agent") or "").lower()
            method = (http.get("http_method") or "").upper()

            feat["http_method_code"] = float(_HTTP_METHOD_MAP.get(method, 0))
            try:
                feat["http_status"] = float(http.get("status") or 0)
            except (ValueError, TypeError):
                pass

            feat["payload_len"] = float(http.get("length") or len(url))

            # Payload pattern detection
            full_payload = url + " " + (http.get("http_request_body") or "")
            if _SQLI_PAT.search(full_payload):
                feat["payload_has_sqli"] = 1.0
            if _XSS_PAT.search(full_payload):
                feat["payload_has_xss"] = 1.0
            if _LOGIN_PAT.search(full_payload):
                feat["payload_has_login"] = 1.0
            if _ADMIN_PAT.search(url):
                feat["is_admin_path"] = 1.0

            # UA detection
            ua_lower = ua.lower()
            for susp in _SUSP_UA:
                if susp in ua_lower:
                    feat["ua_patator"] = 1.0 if "patator" in ua_lower or "hydra" in ua_lower else 0.0
                    feat["ua_curl"] = 1.0 if "curl" in ua_lower else 0.0
                    break
            if any(b in ua_lower for b in ("mozilla", "chrome", "firefox", "safari", "edge")):
                feat["ua_browser"] = 1.0

        # ── DNS ──
        dns = ev.get("dns") or {}
        if dns:
            feat["dns_query_present"] = 1.0
            rrtype = (dns.get("rrtype") or "").upper()
            feat["dns_rrtype_a"] = 1.0 if rrtype == "A" else 0.0
            feat["dns_rrtype_aaaa"] = 1.0 if rrtype == "AAAA" else 0.0
            feat["dns_rrtype_ptr"] = 1.0 if rrtype == "PTR" else 0.0

        # ── TLS ──
        tls = ev.get("tls") or {}
        if tls:
            feat["tls_present"] = 1.0

        return feat

    # ── pfSense features (sparse — only basic network info) ──
    def _build_pf_features(self, entry: dict[str, Any]) -> dict[str, float]:
        feat: dict[str, float] = {f: 0.0 for f in self.feature_order}
        proto = (entry.get("proto") or "").lower()

        try:
            feat["dest_port"] = float(entry.get("dst_port") or 0)
        except (ValueError, TypeError):
            pass

        feat["proto_code"] = float(_PROTO_MAP.get(proto, 0))
        if entry.get("action") == "block":
            feat["alert_present"] = 1.0
            feat["alert_severity"] = 2.0

        try:
            dp = int(entry.get("dst_port") or 0)
            if dp in _SERVICE_PORTS:
                feat["same_service_port_flag"] = 1.0
        except (ValueError, TypeError):
            pass

        # Flow tracking (in-memory)
        flow_key = f"{entry.get('src')}:{entry.get('src_port')}-{entry.get('dst')}:{entry.get('dst_port')}-{proto}"
        now = time.time()
        flow = self._flow_table.get(flow_key)
        if flow is None:
            flow = {"start": now, "last": now, "count": 1, "fwd": 1, "iats": []}
            self._flow_table[flow_key] = flow
        else:
            flow["iats"].append(now - flow["last"])
            if len(flow["iats"]) > 100:
                flow["iats"] = flow["iats"][-50:]
            flow["last"] = now
            flow["count"] += 1
            flow["fwd"] += 1

        dur_s = max(now - flow["start"], 0.001)
        dur_us = dur_s * 1_000_000
        n = flow["count"]
        feat["flow_duration"] = dur_us
        feat["total_fwd_packets"] = float(flow["fwd"])
        feat["flow_pkts_per_s"] = float(n / dur_s)
        feat["fwd_pkts_per_s"] = float(flow["fwd"] / dur_s)

        if flow["iats"]:
            ia = np.array(flow["iats"]) * 1_000_000
            feat["flow_iat_mean"] = float(np.mean(ia))
            feat["flow_iat_std"] = float(np.std(ia)) if len(ia) > 1 else 0.0
            feat["flow_iat_max"] = float(np.max(ia))
            feat["flow_iat_min"] = float(np.min(ia))
            feat["fwd_iat_total"] = float(np.sum(ia))
            feat["fwd_iat_mean"] = feat["flow_iat_mean"]
            feat["fwd_iat_std"] = feat["flow_iat_std"]
            feat["fwd_iat_max"] = feat["flow_iat_max"]
            feat["fwd_iat_min"] = feat["flow_iat_min"]

        est = 60 if proto == "tcp" else 28 if proto == "udp" else 40
        feat["fwd_pkt_len_mean"] = float(est)
        feat["fwd_pkt_len_max"] = float(est)
        feat["fwd_pkt_len_min"] = float(est)
        feat["min_pkt_len"] = float(est)
        feat["max_pkt_len"] = float(est)
        feat["pkt_len_mean"] = float(est)
        feat["avg_pkt_size"] = float(est)
        feat["fwd_header_len"] = float(est * flow["fwd"])
        feat["subflow_fwd_bytes"] = float(est * flow["fwd"])
        feat["total_length_fwd_packets"] = float(est * flow["fwd"])
        feat["flow_bytes_per_s"] = float(est * n / dur_s)
        if proto == "tcp":
            feat["ack_flag_count"] = float(max(0, n - 1))
            feat["psh_flag_count"] = float(max(0, n - 2))
            feat["init_win_bytes_fwd"] = 65535.0
            feat["min_seg_size_fwd"] = 20.0
        if dur_s > 0.1:
            feat["active_mean"] = dur_us * 0.6
            feat["active_max"] = dur_us * 0.8
            feat["active_min"] = dur_us * 0.2
            feat["idle_mean"] = dur_us * 0.3
            feat["idle_max"] = dur_us * 0.5

        # Cleanup stale
        if len(self._flow_table) > 5000:
            cutoff = now - 120
            self._flow_table = {k: v for k, v in self._flow_table.items() if v["last"] > cutoff}

        return feat


# ══════════════════════════════════════════════════════════════════
#  GUI
# ══════════════════════════════════════════════════════════════════
class App(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.title("ANM Monitor — Suricata EVE + pfSense + ML")
        self.geometry("1200x800")
        self.minsize(1000, 680)
        self.configure(fg_color=_BG)
        ctk.set_appearance_mode("dark")

        self._ssh: Any = None
        self._stop = threading.Event()
        self._threads: list[threading.Thread] = []
        self._stats: defaultdict[str, int] = defaultdict(int)
        self._ml: MLEngine | None = None

        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._quit)
        self._tick()
        self._load_ml_async()

    def _build_ui(self) -> None:
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)

        # ── Header ──
        hdr = ctk.CTkFrame(self, fg_color=_CARD, corner_radius=0, height=52)
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.grid_propagate(False)
        ctk.CTkLabel(hdr, text="ANM", font=ctk.CTkFont(size=22, weight="bold"),
                     text_color=_ACCENT).pack(side="left", padx=16)
        ctk.CTkLabel(hdr, text="Suricata + pfSense + ML IDS", text_color=_MUTED,
                     font=ctk.CTkFont(size=13)).pack(side="left")
        self._lbl_clock = ctk.CTkLabel(hdr, text="", text_color=_MUTED,
                                       font=ctk.CTkFont(size=12))
        self._lbl_clock.pack(side="right", padx=16)
        self._lbl_ssh = ctk.CTkLabel(hdr, text="SSH: OFF", text_color=_RED,
                                     font=ctk.CTkFont(size=12, weight="bold"))
        self._lbl_ssh.pack(side="right", padx=8)
        self._lbl_ml = ctk.CTkLabel(hdr, text="ML: loading...", text_color=_ORANGE,
                                    font=ctk.CTkFont(size=12, weight="bold"))
        self._lbl_ml.pack(side="right", padx=8)

        # ── Connection bar ──
        conn = ctk.CTkFrame(self, fg_color=_CARD, corner_radius=12,
                            border_width=1, border_color=_BORDER)
        conn.grid(row=1, column=0, sticky="ew", padx=16, pady=(10, 4))

        r1 = ctk.CTkFrame(conn, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=(10, 4))
        for label, attr, w, default, show in [
            ("Host:", "_ent_host", 160, "103.65.235.234", None),
            ("Port:", "_ent_port", 45, "22", None),
            ("User:", "_ent_user", 80, "root", None),
            ("Pass:", "_ent_pass", 140, "", "*"),
        ]:
            ctk.CTkLabel(r1, text=label, text_color=_MUTED,
                         font=ctk.CTkFont(size=12)).pack(side="left", padx=(6, 2))
            ent = ctk.CTkEntry(r1, width=w, fg_color=_BG, border_color=_BORDER,
                               show=show if show else "")
            ent.pack(side="left", padx=2)
            ent.insert(0, default)
            setattr(self, attr, ent)

        self._btn = ctk.CTkButton(r1, text="Connect", width=110, height=34,
                                  fg_color=_GREEN, hover_color="#2ea043",
                                  font=ctk.CTkFont(size=13, weight="bold"),
                                  command=self._toggle)
        self._btn.pack(side="right", padx=8)

        r2 = ctk.CTkFrame(conn, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=(0, 4))
        ctk.CTkLabel(r2, text="EVE:", text_color=_CYAN, font=ctk.CTkFont(size=12, weight="bold")).pack(side="left", padx=(6, 2))
        self._ent_eve = ctk.CTkEntry(r2, width=280, fg_color=_BG, border_color=_BORDER)
        self._ent_eve.pack(side="left", padx=2)
        self._ent_eve.insert(0, "/var/log/suricata/eve.json")
        ctk.CTkLabel(r2, text="pfSense:", text_color=_ORANGE, font=ctk.CTkFont(size=12, weight="bold")).pack(side="left", padx=(12, 2))
        self._ent_pf = ctk.CTkEntry(r2, width=220, fg_color=_BG, border_color=_BORDER)
        self._ent_pf.pack(side="left", padx=2)
        self._ent_pf.insert(0, "/var/log/filter.log")
        self._chk_eve = ctk.CTkCheckBox(r2, text="EVE", fg_color=_CYAN, font=ctk.CTkFont(size=12))
        self._chk_eve.pack(side="left", padx=(12, 2))
        self._chk_eve.select()
        self._chk_pf = ctk.CTkCheckBox(r2, text="pfSense", fg_color=_ORANGE, font=ctk.CTkFont(size=12))
        self._chk_pf.pack(side="left", padx=2)

        r3 = ctk.CTkFrame(conn, fg_color="transparent")
        r3.pack(fill="x", padx=12, pady=(0, 10))
        ctk.CTkLabel(r3, text="Model:", text_color=_MUTED, font=ctk.CTkFont(size=12)).pack(side="left", padx=(6, 2))
        self._ent_model = ctk.CTkEntry(r3, width=350, fg_color=_BG, border_color=_BORDER)
        self._ent_model.pack(side="left", padx=2)
        self._ent_model.insert(0, str(_MODEL_DIR))
        ctk.CTkButton(r3, text="Reload ML", width=80, height=28,
                       fg_color=_PURPLE, hover_color="#9966cc",
                       command=self._load_ml_async).pack(side="left", padx=8)

        # ── Stats bar ──
        sb = ctk.CTkFrame(self, fg_color=_CARD, corner_radius=10,
                          border_width=1, border_color=_BORDER, height=44)
        sb.grid(row=2, column=0, sticky="ew", padx=16, pady=4)
        sb.pack_propagate(False)
        self._slbl: dict[str, ctk.CTkLabel] = {}
        for key, name, color in [
            ("total", "Total", _TEXT), ("eve", "EVE", _CYAN), ("pf", "pfSense", _ORANGE),
            ("alert", "Suricata Alert", _RED), ("attack", "ML Attack", _ORANGE),
            ("benign", "Benign", _GREEN), ("scan", "PortScan", _PURPLE),
            ("ddos", "DDoS", _RED), ("dos", "DoS", _ORANGE),
        ]:
            ctk.CTkLabel(sb, text=f" {name}:", text_color=_MUTED,
                         font=ctk.CTkFont(size=10)).pack(side="left", padx=(6, 0))
            lbl = ctk.CTkLabel(sb, text="0", text_color=color,
                               font=ctk.CTkFont(size=12, weight="bold"))
            lbl.pack(side="left")
            self._slbl[key] = lbl
        self._lbl_info = ctk.CTkLabel(sb, text="", text_color=_MUTED, font=ctk.CTkFont(size=10))
        self._lbl_info.pack(side="right", padx=10)

        # ── Alert feed ──
        feed = ctk.CTkFrame(self, fg_color=_CARD, corner_radius=12,
                            border_width=1, border_color=_BORDER)
        feed.grid(row=3, column=0, sticky="nsew", padx=16, pady=(4, 12))

        fhdr = ctk.CTkFrame(feed, fg_color="transparent")
        fhdr.pack(fill="x", padx=14, pady=(10, 4))
        self._pulse = ctk.CTkLabel(fhdr, text="●", text_color=_MUTED, font=ctk.CTkFont(size=16))
        self._pulse.pack(side="left")
        ctk.CTkLabel(fhdr, text="  Live Feed (Suricata EVE + pfSense + ML)",
                     font=ctk.CTkFont(size=14, weight="bold"), text_color=_TEXT).pack(side="left")
        ctk.CTkButton(fhdr, text="Clear", width=60, height=26,
                       fg_color=_BORDER, hover_color=_MUTED, command=self._clear).pack(side="right")
        self._chk_attack_only = ctk.CTkCheckBox(fhdr, text="Attacks only",
                                                fg_color=_RED, font=ctk.CTkFont(size=12))
        self._chk_attack_only.pack(side="right", padx=8)
        self._chk_alert_only = ctk.CTkCheckBox(fhdr, text="Alerts only",
                                               fg_color=_ORANGE, font=ctk.CTkFont(size=12))
        self._chk_alert_only.pack(side="right", padx=4)

        self._feed = ctk.CTkTextbox(feed, font=ctk.CTkFont(family="Consolas", size=11),
                                    fg_color=_BG, text_color=_TEXT, corner_radius=8)
        self._feed.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    # ── ML ──
    def _load_ml_async(self) -> None:
        def job() -> None:
            d = self._ent_model.get().strip() or str(_MODEL_DIR)
            engine = MLEngine(d)
            self._ml = engine
            def ui() -> None:
                if engine.ready:
                    self._lbl_ml.configure(text=f"ML: OK ({len(engine.feature_order)}f)", text_color=_GREEN)
                    self._log(f"ML loaded: {len(engine.feature_order)} features, 7 classes", _GREEN)
                else:
                    self._lbl_ml.configure(text="ML: FAILED", text_color=_RED)
                    self._log("ML load failed — check model path", _RED)
            self.after(0, ui)
        threading.Thread(target=job, daemon=True).start()

    # ── Clock ──
    def _tick(self) -> None:
        try:
            self._lbl_clock.configure(text=datetime.now().strftime("%Y-%m-%d  %H:%M:%S"))
            alive = self._ssh and any(t.is_alive() for t in self._threads)
            self._pulse.configure(text_color=_GREEN if alive else _MUTED)
            for k, lbl in self._slbl.items():
                lbl.configure(text=str(self._stats.get(k, 0)))
            flows = len(self._ml._flow_table) if self._ml else 0
            self._lbl_info.configure(text=f"flows: {flows}")
        except Exception:
            pass
        self.after(1000, self._tick)

    # ── Connect / Disconnect ──
    def _toggle(self) -> None:
        if self._ssh:
            self._disconnect()
        else:
            self._connect()

    def _connect(self) -> None:
        if not paramiko:
            self._log("pip install paramiko!", _RED)
            return
        host = self._ent_host.get().strip()
        port = int(self._ent_port.get().strip() or "22")
        user = self._ent_user.get().strip()
        pwd = self._ent_pass.get().strip()
        if not host:
            self._log("Dien host!", _ORANGE)
            return

        do_eve = bool(self._chk_eve.get())
        do_pf = bool(self._chk_pf.get())
        if not do_eve and not do_pf:
            self._log("Chon it nhat 1 nguon: EVE hoac pfSense!", _ORANGE)
            return

        self._btn.configure(text="Connecting...", state="disabled")
        self._log(f"SSH -> {user}@{host}:{port}...", _CYAN)

        def job() -> None:
            try:
                c = paramiko.SSHClient()
                c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                c.connect(host, port=port, username=user, password=pwd, timeout=15)
                self._ssh = c
                self._stop.clear()
                self._threads.clear()
                self.after(0, lambda: self._on_ok(host))

                # Start tail threads
                if do_eve:
                    eve_path = self._ent_eve.get().strip()
                    t = threading.Thread(target=self._tail_eve, args=(eve_path,), daemon=True)
                    t.start()
                    self._threads.append(t)
                    self.after(0, lambda: self._log(f"Tailing EVE: {eve_path}", _CYAN))

                if do_pf:
                    pf_path = self._ent_pf.get().strip()
                    t = threading.Thread(target=self._tail_pf, args=(pf_path,), daemon=True)
                    t.start()
                    self._threads.append(t)
                    self.after(0, lambda: self._log(f"Tailing pfSense: {pf_path}", _ORANGE))

                # Wait for all threads
                for t in self._threads:
                    t.join()
            except Exception as e:
                self.after(0, lambda: self._on_fail(str(e)))
            finally:
                self.after(0, self._on_disc)

        t = threading.Thread(target=job, daemon=True)
        t.start()

    def _on_ok(self, host: str) -> None:
        self._lbl_ssh.configure(text=f"SSH: {host}", text_color=_GREEN)
        self._btn.configure(text="Disconnect", state="normal", fg_color=_RED, hover_color="#da3633")
        self._log(f"Connected to {host}!", _GREEN)

    def _on_fail(self, err: str) -> None:
        self._log(f"SSH failed: {err}", _RED)
        self._btn.configure(text="Connect", state="normal", fg_color=_GREEN, hover_color="#2ea043")

    def _on_disc(self) -> None:
        self._ssh = None
        self._lbl_ssh.configure(text="SSH: OFF", text_color=_RED)
        self._btn.configure(text="Connect", state="normal", fg_color=_GREEN, hover_color="#2ea043")

    def _disconnect(self) -> None:
        self._stop.set()
        if self._ssh:
            try:
                self._ssh.close()
            except Exception:
                pass
            self._ssh = None
        self._log("Disconnected", _MUTED)

    # ── Tail EVE (Suricata NDJSON) ──
    def _tail_eve(self, path: str) -> None:
        client = self._ssh
        if not client:
            return
        try:
            _in, stdout, _err = client.exec_command(f"tail -F {path}", get_pty=True)
            chan = stdout.channel
            buf = ""
            while not self._stop.is_set():
                if chan.recv_ready():
                    chunk = chan.recv(16384).decode("utf-8", errors="replace")
                    buf += chunk
                    while "\n" in buf:
                        line, buf = buf.split("\n", 1)
                        line = line.strip()
                        if line:
                            entry = _parse_eve_line(line)
                            if entry:
                                self._process_entry(entry)
                elif chan.exit_status_ready():
                    break
                else:
                    time.sleep(0.05)
        except Exception as e:
            if not self._stop.is_set():
                self.after(0, lambda: self._log(f"EVE tail error: {e}", _RED))

    # ── Tail pfSense filter.log ──
    def _tail_pf(self, path: str) -> None:
        client = self._ssh
        if not client:
            return
        try:
            cmd = f"clog {path} | tail -f" if "filter.log" in path else f"tail -F {path}"
            _in, stdout, _err = client.exec_command(cmd, get_pty=True)
            chan = stdout.channel
            buf = ""
            while not self._stop.is_set():
                if chan.recv_ready():
                    chunk = chan.recv(8192).decode("utf-8", errors="replace")
                    buf += chunk
                    while "\n" in buf:
                        line, buf = buf.split("\n", 1)
                        line = line.strip()
                        if line:
                            entry = _parse_pf_line(line)
                            if entry:
                                self._process_entry(entry)
                elif chan.exit_status_ready():
                    break
                else:
                    time.sleep(0.05)
        except Exception as e:
            if not self._stop.is_set():
                self.after(0, lambda: self._log(f"pfSense tail error: {e}", _RED))

    # ── Process any entry ──
    def _process_entry(self, entry: dict[str, Any]) -> None:
        src_type = entry.get("_src", "?")
        self._stats["total"] += 1
        if src_type == "eve":
            self._stats["eve"] += 1
        else:
            self._stats["pf"] += 1

        action = entry.get("action", "")
        if action == "block":
            self._stats["block"] += 1

        # Suricata alert
        is_suricata_alert = entry.get("event_type") == "alert"
        if is_suricata_alert:
            self._stats["alert"] += 1

        # ML prediction
        ml_label = ""
        ml_conf = 0.0
        ml_proba = {}
        if self._ml and self._ml.ready:
            ml_label, ml_conf, ml_proba = self._ml.predict(entry)
            if ml_label and ml_label.upper() != "BENIGN":
                self._stats["attack"] += 1
                cat = ml_label.upper()
                if "DDOS" in cat:
                    self._stats["ddos"] += 1
                elif "DOS" in cat:
                    self._stats["dos"] += 1
                elif "PORTSCAN" in cat:
                    self._stats["scan"] += 1
            elif ml_label:
                self._stats["benign"] += 1

        # Filters
        alert_only = attack_only = False
        try:
            alert_only = bool(self._chk_alert_only.get())
            attack_only = bool(self._chk_attack_only.get())
        except Exception:
            pass
        if alert_only and not is_suricata_alert and action != "block":
            return
        if attack_only and ml_label and ml_label.upper() == "BENIGN":
            return

        # Format
        ts_now = datetime.now().strftime("%H:%M:%S")
        tag = "EVE" if src_type == "eve" else "PF "

        # Build info line
        parts = [f"[{ts_now}] {tag}"]
        if src_type == "eve":
            et = entry.get("event_type", "?")
            parts.append(f" {et:8s}")
            if is_suricata_alert:
                parts.append(f" SIG: {entry.get('alert_sig', '')[:60]}")
        else:
            act_s = "BLOCK" if action == "block" else "PASS " if action == "pass" else action.upper()[:5]
            parts.append(f" {act_s}")
            iface = entry.get("iface", "")
            if iface:
                parts.append(f" {iface:6s}")

        parts.append(f" | {entry.get('src', '?')}:{entry.get('src_port', '')} -> "
                     f"{entry.get('dst', '?')}:{entry.get('dst_port', '')} | {entry.get('proto', '')}")

        if ml_label:
            parts.append(f" | ML: {ml_label} ({ml_conf:.0%})")
            if ml_proba:
                top3 = sorted(ml_proba.items(), key=lambda x: -x[1])[:3]
                parts.append(" [" + " ".join(f"{k}:{v:.0%}" for k, v in top3) + "]")

        line = "".join(parts) + "\n"
        self.after(0, lambda l=line: self._append(l))

    # ── UI helpers ──
    def _log(self, msg: str, color: str = _TEXT) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        self._append(f"[{ts}] -- {msg} --\n")

    def _append(self, text: str) -> None:
        try:
            if not self.winfo_exists():
                return
            self._feed.insert("end", text)
            lines = self._feed.get("1.0", "end").count("\n")
            if lines > 3000:
                self._feed.delete("1.0", "800.0")
            self._feed.see("end")
        except tk.TclError:
            pass

    def _clear(self) -> None:
        self._feed.delete("1.0", "end")
        self._stats.clear()

    def _quit(self) -> None:
        self._disconnect()
        self.destroy()


if __name__ == "__main__":
    ctk.set_default_color_theme("blue")
    App().mainloop()
